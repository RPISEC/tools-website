#include <stdio.h>

int main(int argc, char** argv) {
    int secret = 1337;
    int input = 0;
    printf("I bet you don't know the secret number!\n");
    printf("Enter the secret, IF YOU DARE ===>> ");
    fscanf(stdin, "%d", &input);

    if (input == secret) {
        printf("That's right!\n");
    } else {
        printf("That's not right...\n");
    }
}
