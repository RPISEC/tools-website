void win() {
    system("/bin/sh");
}

int main (int argc, char** argv) {
    char buf[32];
    gets(buf);
    puts(buf);
}
