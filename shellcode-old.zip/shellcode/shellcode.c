
#include <stdio.h>

//gcc -m32 -fno-stack-protector -z execstack shellcode.c -o shellcode -no-pie

//void win() {
//    printf("You did it!\n");
//    system("/bin/sh");
//}

char name[64];

int main() {
    //Disable buffering (ignore this)
    setvbuf(stdout, 0, _IONBF, 0);

    printf("-[      \033[32mWelcome to \033[1;31mRPISEC\033[0;32m reward points!\033[0m      ]-\n");
    printf("-[         \033[33;1mv1.2                               \033[0m]-\n");
    printf("-[      \033[33mWe finally figured it out             \033[0m]-\n");
    printf("-[  \033[33mAll useless functions have been removed   \033[0m]-\n");
    printf("Can you still pwn me? \n");

    printf("What do they call you: ");
    fscanf(stdin, "%s", name);

    char pw[64];
    printf("Hi %s, what is the secret password? ", name);
    fscanf(stdin, "%s", pw);
    if (!strcmp(pw, "Patience is the water of the follower of the way of the tea")) {
        printf("Welcome young hacker...\n");
        printf("Hmm... I seemed to have misplaced my flag, sorry :(\n");
    }
    else
        printf("Err... no\n");

    return 0;
}
