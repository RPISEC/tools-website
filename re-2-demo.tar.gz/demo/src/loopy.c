#include <stdio.h>
#include <unistd.h>

int main() {
    printf("I'll print your flag, just give me a minute...\n");
    
    for (int i = 0; i < 1000000; i ++) {
        sleep(1);
    }
    
    printf("flag{that_took_a_while}\n");
}

