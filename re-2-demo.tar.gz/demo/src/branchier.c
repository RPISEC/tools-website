#include <stdio.h>

int main() {
    printf("What's the correct number?\n");
    // Read input
    int input;
    fscanf(stdin, "%d", &input);

    if (input > 4) {
        if (input > 6) {
            if (input > 7) {
                //8
                printf("That's not it\n");
            } else {
                //7
                printf("That's not it\n");
            }
        } else {
            if (input > 5) {
                //6
                printf("That's not it\n");
            } else {
                //5
                printf("That's not it\n");
            }
        }
    } else {
        if (input > 2) {
            if (input > 3) {
                //4
                printf("That's not it\n");
            } else {
                //3
                printf("You got it!\n");
            }
        } else {
            if (input > 1) {
                //2
                printf("That's not it\n");
            } else {
                //1
                printf("That's not it\n");
            }
        }
    }

    return 0;
}

