#include <stdio.h>

int main() {
    char guess[16];
    printf("Y or N?\n");
    // Extremely insecure method of reading user input (bonus challenge: pop a shell)
    gets(guess);

    if (guess[0] == 'Y') {
        printf("Yes!\n");
    } else {
        printf("No!\n");
    }

    return 0;
}
