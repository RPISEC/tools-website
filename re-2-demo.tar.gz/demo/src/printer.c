#include <stdio.h>

int main() {
    printf("RPISEC: Reverse Engineering and Pwning\n");
    return 0;
}

