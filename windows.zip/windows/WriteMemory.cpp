#include <Windows.h>
#include <string>
#include <iostream>
#include <TlHelp32.h>

#define OFFSET 0x337C


using namespace std;

HANDLE get_handle(const char* process_name, PROCESSENTRY32& entry) {
	entry.dwSize = sizeof(PROCESSENTRY32);

	HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
	if (Process32First(snapshot, &entry) == TRUE) {
		while (Process32Next(snapshot, &entry) == TRUE) {
			if (strcmp(entry.szExeFile, process_name) == 0) {
				return OpenProcess(PROCESS_ALL_ACCESS, FALSE, entry.th32ProcessID);
			}
		}
	}
	CloseHandle(snapshot);
}

DWORD_PTR getmodulebase(const char* module_name, PROCESSENTRY32& entry) {
	HANDLE modules = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, entry.th32ProcessID);
	MODULEENTRY32 module;
	if (Module32First(modules, &module)) {
		cout << module.szModule << endl;
		if (strcmp(module.szModule, module_name) == 0)
			return (DWORD_PTR)module.modBaseAddr;
		while (Module32Next(modules, &module)) {
			if (strcmp(module.szModule, module_name) == 0) {
				return (DWORD_PTR)module.modBaseAddr;
			}
		}
	}
	return NULL;
}

int main(int argc, char* argv[]) {
	PROCESSENTRY32 entry;
	HANDLE h = get_handle("WindowsDemo.exe", entry);
	DWORD_PTR location = getmodulebase("WindowsDemo.exe",entry) + OFFSET;
	int size = 0;
	WriteProcessMemory(h, (LPVOID)location, &size, sizeof(int), NULL);
	return 0;
}