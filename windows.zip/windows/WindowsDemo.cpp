#include <Windows.h>
#include <iostream>

struct demo {
	int value;
	void* print_value;
};

struct demo d;

void print_demo_obj() {
	d.value += 10;
	std::cout << d.value << std::endl;
}

int main(int argc, char* argv[]) {
	d.value = 5;
	d.print_value = print_demo_obj;

	while (true) {
		((void(*)())d.print_value)();
		Sleep(1000);
	}

	return 0;
}