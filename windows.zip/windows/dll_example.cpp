// dllmain.cpp : Defines the entry point for the DLL application.
#include "pch.h"

#define DATA_OFFSET 0x1C170
#define FUNCTION_OFFSET 0x1C170+0x8

DWORD_PTR original_function = 0;
HMODULE module = 0;

void mod_data() {
	DWORD_PTR data_addr = (DWORD_PTR)module + DATA_OFFSET;
	// If we set this data to 0, it should be 10 when we call the original function.
	*(DWORD_PTR*)data_addr = 0;
}

// This will get called on our print data function
void hook() {
	// Mod data just to demonstrate we can call other functions
	mod_data();
	// Call the original function- technically, not needed
	((void(*)())original_function)();
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     ) {
	// Get base addr of binary in process
	module = GetModuleHandleA("WindowsDemo.exe");
	// Offset into data segment
	DWORD_PTR func_addr = (DWORD_PTR)module + FUNCTION_OFFSET;
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    case DLL_THREAD_ATTACH:
		MessageBoxA(NULL, "Injection success!", "test", MB_OK);
		// Overwrite function pointer
		original_function = *(DWORD_PTR*)func_addr;
		*(DWORD_PTR*)func_addr = (DWORD_PTR)hook;
		break;
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

