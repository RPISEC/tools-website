#include <Windows.h>
#include <TlHelp32.h>
#include <iostream>
#include <string.h>

using namespace std;

PROCESSENTRY32 entry;
HANDLE proc_handle = NULL;

void get_handle(char* process_name) {
	entry.dwSize = sizeof(PROCESSENTRY32);

	HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
	if (Process32First(snapshot, &entry) == TRUE) {
		while (Process32Next(snapshot, &entry) == TRUE) {
			wstring ws(entry.szExeFile);
			string newstr(ws.begin(), ws.end());
			if (strcmp(newstr.c_str(), process_name) == 0) {
				proc_handle = OpenProcess(PROCESS_ALL_ACCESS, FALSE, entry.th32ProcessID);
			}
		}
	}
	CloseHandle(snapshot);
}

BYTE* getmodulebase(const char* module_name) {
	HANDLE modules = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, entry.th32ProcessID);
	MODULEENTRY32 module;
	if (Module32First(modules, &module)) {
		while (Module32Next(modules, &module)) {
			wstring ws(module.szModule);
			string newstr(ws.begin(), ws.end());
			if (strcmp(newstr.c_str(), module_name) == 0) {
				return module.modBaseAddr;
			}
		}
	}
	return NULL;
}

int main(int argc, char* argv[]) {

	get_handle(argv[1]);
	if (!proc_handle) {
		cout << "Error: could not find target process" << endl;
		goto EXIT;
	}

	// Virtual alloc
	LPVOID dll_name = VirtualAllocEx(proc_handle, NULL, strlen(argv[2]), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	if (!dll_name) {
		cout << "Error: coult not virtual allocate ex" << endl;
		goto EXIT;
	}
	HMODULE kernelmod = GetModuleHandle(L"kernel32.dll");
	if (!kernelmod) {
		cout << "Error- count not find kernel32.dll" << endl;
		goto EXIT;
	}
	LPVOID lladdr = GetProcAddress(kernelmod, "LoadLibraryA");
	WriteProcessMemory(proc_handle, dll_name, argv[2], strlen(argv[2]), NULL);
	CreateRemoteThreadEx(proc_handle, NULL, 0, (LPTHREAD_START_ROUTINE)lladdr, dll_name, NULL, NULL, NULL);
	EXIT:
	system("PAUSE");
	return 0;
}