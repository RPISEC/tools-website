#include<stdio.h>
#include<string.h>

int isFlag(char*);

int main()
{
	char buff[31];
	printf("Please enter the flag: ");
	fgets(buff,31,stdin);
	if(!isFlag(buff))
	{
		printf("Correct! %s is the flag!\n",buff);
	}
	else
	{
		printf("Sorry, %s is not the flag\n",buff);
	}
	return 0;
}

int isFlag(char* buff)
{
	return strncmp("flag{th3_f4ult_1n_0ur_str1ngs}",buff,30);
}

