from hash import md5
import random

words = [x.strip() for x in open("wordlists/english-1000.txt").readlines()]

results = []

for _ in range(100):
  w1, w2 = random.choices(words, k=2)
  results.append(md5(w1 + "-" + w2))

with open("md5-salted.txt", "w") as file:
  file.write("\n".join(results))