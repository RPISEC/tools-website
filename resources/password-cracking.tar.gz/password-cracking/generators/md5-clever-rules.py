from hash import md5
import random
import binascii

passwords = [
  "P@ssw0rd!",
  "computer!!",
  "july1983",
  "CoMpUtEr",
  "111111111111111111",
]

results = []

for password in passwords:
  results.append(md5(password))

with open("md5-clever-rules.txt", "w") as file:
  for password in results:
    file.write(password)
    file.write("\n")