from hash import md5

accounts = [
  ["Alice", "123456"],
  ["Bob", "potato"],
  ["Alice 2: Alice Harder", "g"],
  ["crux", "rpisec"]
]

results = []

for username, password in accounts:
  results.append(md5(password))

with open("md5.txt", "w") as file:
  file.write("\n".join(results))