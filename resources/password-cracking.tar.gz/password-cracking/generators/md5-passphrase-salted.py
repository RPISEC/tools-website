from hash import md5
import random
import binascii

words = [x.strip() for x in open("wordlists/english-1000.txt").readlines()]

results = []

w1, w2 = random.choices(words, k=2)
password = w1 + "-" + w2
print(password)

for _ in range(100):
  salt = str(random.randint(1, 1 << 16))
  results.append([md5(password + salt), salt])

with open("md5-passphrase-salted.txt", "w") as file:
  for hash, salt in results:
    file.write(hash)
    file.write(":")
    file.write(salt)
    file.write("\n")