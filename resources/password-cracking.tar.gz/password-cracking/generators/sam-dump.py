from hash import lm, ntlm
accounts = [
  ["Administrator", 500, "computer123"],
  ["Alice", 1337, "password"],
  ["Bob", 10000, "july2003"]
]

results = []

for uid, rid, password in accounts:
  results.append(
    [
      uid,
      str(rid),
      lm(password),
      ntlm(password)
    ]
  )

with open("sam-dump.txt", "w") as file:
  for result in results:
    file.write(":".join(result))
    file.write(":::")
    file.write("\n")