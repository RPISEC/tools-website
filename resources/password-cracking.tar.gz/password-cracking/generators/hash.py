import hashlib
from Crypto.Cipher import DES
import binascii
import bitstring

def lm(password):
  password = password[0:14]
  password = password.upper()
  password = password.encode("utf-8")
  password = password + b"\x00" * (14 - len(password))
  first, second = password[0:7], password[7:14]
  crypted = b""

  for part in first, second:
    bits = bitstring.BitArray(part)
    key = bitstring.BitArray()
    for index in range(0, 56, 7):
      key.append(bits[index:index+7])
      key.append(bitstring.BitArray(uint=0, length=1))

    key = key.tobytes()
    cipher = DES.new(key, DES.MODE_ECB)

  
    crypted += cipher.encrypt(b"KGS!@#$%")
  
  return binascii.hexlify(crypted).decode("utf-8")


def ntlm(password):
  h = hashlib.new("md4")
  h.update(password.encode("utf-16le"))
  return h.hexdigest()

def md5(password):
  h = hashlib.md5()
  h.update(password.encode("utf-8"))
  return h.hexdigest()