
#include <stdio.h>

//gcc -m32 -fno-stack-protector --static rop1.c -o rop1 -no-pie

//void win() {
//    printf("You did it!\n");
//    system("/bin/sh");
//}

int main() {
    //Disable buffering (ignore this)
    setvbuf(stdout, 0, _IONBF, 0);

    printf("-[      \033[32mWelcome to \033[1;31mRPISEC\033[0;32m reward points!\033[0m      ]-\n");
    printf("-[         \033[33;1mv1.2                               \033[0m]-\n");
    printf("-[      \033[33mWe see what you were doing :P         \033[0m]-\n");
    printf("-[  \033[33mYou can't inject your own code anymore!   \033[0m]-\n");
    printf("Can you still pwn me? \n");


    char name[64];
    printf("What do they call you: ");
    fscanf(stdin, "%s", name);
    printf("Welcome young hacker...  Enjoying the DEP?!  What u gonna do about it hmmmmmm?\n");

    return 0;
}
