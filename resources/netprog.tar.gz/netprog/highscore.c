#include <stdio.h>

void get_high_score() {
    long long score = 0;
    char name[16];
    printf("Whats' your name? ");

    gets(name);

    printf("\n");

    printf("Your score is: %lld\n\n", score);

    if (score > 0x1337) {
        printf("New high score!\n\n");
    } else {
        printf("No dice :(\n\n");
    }

    printf("Your name was: %s", name);
}

int main(int argc, char** argv) {
get_high_score();
}