#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void heap_spray(int count, int to_free, char* secret) {
    char** buffers = malloc(sizeof(char*) * count);

    for (int i=0; i<count; i++) {
        buffers[i] = malloc(64);
        strcpy(buffers[i], "Mangled by heap");
        snprintf(buffers[i] + 16, 16, "Heap #%d", i);
        strcpy(buffers[i] + 32, secret);
        strcpy(buffers[i] + 48, secret);
    }

    for (int i=count-1; i >= count - to_free; i--) {
        free(buffers[i]);
    }
}

int main (int argc, char** argv) {
    srand(time(NULL));
    char password[17];

    for (int i = 0; i < 16; i++) {
        password[i] = 65 + (rand() % 26);
    }

    password[16] = 0;

    heap_spray(100, 50, password);

    int claimed_length;

    printf("How long do you *say* the message is? ");

    scanf("%d", &claimed_length);
    getchar();

    int length;

    printf("How long is the message, really? ");

    scanf("%d", &length);
    getchar();

    char* message = malloc(length);
    memset(message, 0, length);

    printf("\n\nWhat is your message? ");

    fgets(message, length, stdin);

    printf("Allocating %d bytes for your %d-length string...\n", claimed_length, strlen(message));

    char* buffer = malloc(claimed_length);

    memcpy(buffer, message, claimed_length);

    printf("Here's your string: ");

    fwrite(buffer, sizeof(char), claimed_length, stdout);

    printf("\n\n");

    printf("Okay, what's the password? ");

    fgets(message, 512, stdin);

    if (strncmp(message, password, 16) == 0) {
        printf("System: hacked\n\n");

    } else {
        printf("WRONG!\n\n");
    }
}