#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc, char** argv) {
    char* buffer = malloc(64);

    char* dangerzone[10];

    for (int i=0; i<10; i++) {
        dangerzone[i] = malloc(64);
        strcpy(dangerzone[i], "This data is very important. Please do not destroy it.\n");
        printf("Buffer #%d is at: %p\n", i, dangerzone[i]);
    }

    free(buffer);

    printf("How much space do you want? ");

    int length;

    scanf("%d", &length);
    getchar();

    printf("\nSetting up your memory...\n");

    char to_alloc = length;

    printf("I'm going to allocate %hd bytes\n", to_alloc);

    buffer = malloc(to_alloc);

    printf("Your buffer is at: %p\n", buffer);

    memset(buffer, 'A', length);

    printf("Memory configured! Now let's check the important data...\n\n");

    for (int i=0; i<10; i++) {
        printf("%s", dangerzone[i]);
    }
}