int foo(int a, int b) {
    int c = a + b;
}

int main (int argc, char** argv) {
    foo(1, 2);
}
