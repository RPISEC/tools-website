void baz(void) {

}

void bar(void) {
	baz();
}

void foo(void) {
	bar();
}

int main(int argc, char** argv) {
	foo();
}



