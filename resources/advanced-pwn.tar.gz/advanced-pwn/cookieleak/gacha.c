#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>

// gcc -m32 -g -zexecstack -fstack-protector-all -no-pie -fno-pic -masm=intel -O0 gacha.c -o gacha.out

unsigned int count = 0;

unsigned int get_ticket(void) {
  unsigned int num = 0;
  // stackoverflow told me this was a random number,
  // lets use it as a ticket seed!
  asm("mov %0, DWORD PTR [ebp-0xc]" : "=r" (num));
  num += count;
  count += 1;
  return num;
}

char const *prizes[] = {
  "some old pentium processor",
  "an Intel i5-11600k",
  "an AMD Ryzen 5 5600X",
  "an Intel i3-8100",
};

#define PRIZE_LEN (sizeof(prizes)/sizeof(char*))

void gacha(void) {
  while (1) {
    puts("What would you like to do?");
    puts("1. Play gacha");
    puts("2. Exit");
    char input[32];
    gets(input);
    int choice = atoi(input);
    switch (choice) {
    case 1:
      {
	unsigned int ticket = get_ticket();
	printf("Ticket no: %u\n", ticket);
	usleep(500000);
	printf("Today's lucky number is: %u\n", input);
	uint64_t n = ticket * ticket;
	n += 1000;
	n %= 13;
	char const *prize = prizes[n % PRIZE_LEN];
	usleep(500000);
	printf("You won... %s\n\n", prize);
	usleep(1000000);
      }
      break;
    case 2:
      return;
    default:
      puts("That's not an option!");
      break;
    }
  }
}

int main(void)
{
  setvbuf(stdout, 0, _IONBF, 0);
  puts("Welcome to the CPU gacha");
  usleep(500000);
  gacha();
}

