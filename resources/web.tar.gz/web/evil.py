import json
from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("evil.html")

@app.route("/secure")
def secure():
    return render_template("secure.html")

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=1338)