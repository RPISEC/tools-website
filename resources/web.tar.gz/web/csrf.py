import json
from flask import Flask, render_template, request, make_response

nukes_launched = False

app = Flask(__name__)

def set_val(key, value):
    data = json.load(open("status.json", encoding="utf-8"))
    data[key] = value
    with open("status.json", "w", encoding="utf-8") as file:
        json.dump(data, file)

def get_val(key):
    data = json.load(open("status.json", encoding="utf-8"))
    return data[key]

defaults = {
    "nukes": False,
    "cors": False
}

json.dump(defaults, open("status.json", "w", encoding="utf-8"))

@app.route("/")
def index():
    nukes = get_val("nukes")
    return render_template("index.html", nukes=nukes, cookie=request.cookies.get("key", default="") == "swordfish")

@app.route("/launch-nukes", methods=["GET", "POST"])
def nuke():
    set_val("nukes", True)

    return "uh oh"

@app.route("/reset-nukes")
def reset():
    set_val("nukes", False)

    return "nukes reset!"

@app.route("/get-key-lax")
def keyLax():
    r = make_response("Here's your cookie!")
    r.set_cookie("key", "swordfish", samesite="Lax")
    return r

@app.route("/reset-key")
def clearkey():
    r = make_response("I ate your cookie!")
    r.set_cookie("key", "nocookieforyou")
    return r

@app.route("/launch-nukes-secure", methods=["GET", "POST"])
def nuke_secure():
    if "key" not in request.cookies:
        return "You don't have have a cookie"
    if request.cookies.get("key") != "swordfish":
        return "Wrong cookie"
    set_val("nukes", True)

    return "uh oh"

@app.route("/enable-cors")
def enable_cors():
    set_val("cors", True)
    return "CORS set to localhost:1337"

@app.route("/disable-cors")
def disable_cors():
    set_val("cors", False)
    return "CORS set to *"


@app.after_request
def headers(response):
    if get_val("cors"):
        response.headers["Access-Control-Allow-Origin"] = "localhost:1337"
    else:
        response.headers["Access-Control-Allow-Origin"] = "*"
    return response

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=1337)