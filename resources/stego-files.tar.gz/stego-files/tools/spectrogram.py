import librosa
import soundfile
from PIL import Image,ImageOps
import numpy as np

import math
import sys

def draw_hline(spectrum, x0, x1, y):
    draw_box(spectrum, x0, y - 0.05, x1, y + 0.05)

def draw_vline(spectrum, y0, y1, x):
    draw_box(spectrum, x - 0.02, y0, x + 0.02, y1)

def draw_box(spectrum, x0, y0, x1, y1):
    x0 = math.floor(x0 * spectrum.shape[1])
    x1 = math.floor(x1 * spectrum.shape[1])
    y0 = math.floor(y0 * spectrum.shape[0])
    y1 = math.floor(y1 * spectrum.shape[0])
    spectrum[y0:y1,x0:x1] *= 4
    print(y0, y1, x0, x1)

def loss(filename):
    data, rate = librosa.load(filename, sr=None)
    spectrum = librosa.stft(data)
    draw_hline(spectrum, 0.05, 0.95, 0.5)
    draw_vline(spectrum, 0.05, 0.95, 0.5)
    draw_vline(spectrum, 0.5, 0.9, 0.15)
    draw_vline(spectrum, 0.5, 0.9, 0.7)
    draw_vline(spectrum, 0.5, 0.75, 0.8)
    draw_vline(spectrum, 0.1, 0.4, 0.2)
    draw_vline(spectrum, 0.1, 0.4, 0.35)
    draw_vline(spectrum, 0.1, 0.4, 0.6)
    draw_hline(spectrum, 0.7, 0.95, 0.15)
    audio = librosa.istft(spectrum)
    soundfile.write("loss.wav", audio, rate)

def process(filename, path, outfile):
    data, rate = librosa.load(filename, sr=None)
    spectrum = librosa.stft(data)
    (width, height) = spectrum.shape[1], spectrum.shape[0]
    img = Image.open(path).resize((width, height)).convert("L")
    img = ImageOps.flip(img)
    array = np.array(img)

    print(array)
    spectrum = 0.9 * spectrum + 0.1 * array

    audio = librosa.istft(spectrum)
    soundfile.write(outfile, audio, rate)

if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage: {0} [wav-file] [image] [output file]".format(sys.argv[0]))
        sys.exit(1)
    if sys.argv[2] == "loss.jpg":
        loss(sys.argv[1])
    else:
        process(sys.argv[1], sys.argv[2], sys.argv[3])
