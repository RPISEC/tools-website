from PIL import Image
import numpy as np 
import sys
import wave 

def load_image(path):
    i = Image.open(path)
    return i

def encode(array, data):
    # how many bits we've written so far
    bit = 0
    for indices in np.ndindex(array.shape):
        # which byte of the secret we're looking at
        byte = bit // 8
        # which bit of the secret we're looking at, counting from the right
        shift = bit % 8
        # zero out the lowest cover bit and OR it with the next secret bit
        array[indices] = (array[indices] & (~1)) | ((ord(data[byte]) >> shift) & 1)
        bit += 1
        if bit >= len(data) * 8:
            break

def decode(array, limit):
    bit = 0
    byte = 0
    result = ""
    for indices in np.ndindex(array.shape):
        shift = bit % 8
        byte += (array[indices] & 1) << shift
        # once we complete a byte, we add it to the result
        if shift == 7:
            result += chr(byte)
            byte = 0
        bit += 1
        if bit >= limit * 8:
            break
    # throw in whatever's left over for good measure
    result += chr(byte)
    return result
    
if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: {0} encode|decode image|audio [input-file] [text-to-encode|length-to-decide] [encoded-file]".format(sys.argv[0]))
        sys.exit(1)
    if sys.argv[2] == "image":
        image = load_image(sys.argv[3])
        data = np.array(image)
        if sys.argv[1] == "encode":
            secret = sys.argv[4]
            encode(data, secret)
            new_image = Image.fromarray(data)
            new_image.save(sys.argv[5])
        elif sys.argv[1] == "decode":
            secret = decode(data, int(sys.argv[4]))
            print(secret)
            
    elif sys.argv[2] == "audio":
        audio = wave.open(sys.argv[3])
        audio_data = audio.readframes(2<<16)
        data = np.array(np.frombuffer(audio_data, dtype="uint8"))
        if sys.argv[1] == "encode":
            secret = sys.argv[4]
            encode(data, secret)
            new_audio = wave.open(sys.argv[5], "wb")
            new_audio.setparams(audio.getparams())
            new_audio.writeframes(data)
            new_audio.close()
        elif sys.argv[1] == "decode":
            secret = decode(data, int(sys.argv[4]))
            print(secret)
    else:
        print("Invalid kind of media; pick image or audio")
        sys.exit(1)
    
    