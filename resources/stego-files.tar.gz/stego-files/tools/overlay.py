from PIL import Image
import numpy as np
import sys

def combine(base, overlay, output, bits):
    base_img = Image.open(base)
    mode = base_img.mode
    base_img = np.array(base_img)
    # we first resize the overlay...
    overlay_img = Image.open(overlay).resize((base_img.shape[1], base_img.shape[0]))
    # ...then convert it to match the mode of the base image (e.g. RGBA, grayscale, etc.)
    overlay_img = overlay_img.convert(mode)
    overlay_img = np.array(overlay_img)
    # knock out the lowest bits
    base_img &= (255 - ((1 << bits) - 1))
    # compress from 0-255 to 0-X, where X is 2^bits - 1
    overlay_img //= (1 << (8 - bits))
    # element-wise addition! thank you, numpy :)
    base_img += overlay_img
    Image.fromarray(base_img).save(output)



if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage: {0} [base image] [overlay image] [output image] [num-bits]=1".format(sys.argv[0]))
        sys.exit(1)
    else:
        if len(sys.argv) >= 5:
            bits = int(sys.argv[4])
        else:
            bits = 1
        combine(sys.argv[1], sys.argv[2], sys.argv[3], bits)