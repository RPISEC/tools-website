import sys

if sys.argv[1] == "encode":
    flag = open(sys.argv[2]).read()
    output = open(sys.argv[3], "w")
    output_normal = open(sys.argv[4], "w")

    text = "abcdefghijklmnopqrstuvwxyz"

    result = []
    untouched = []

    next_char = 0

    for i in range(len(flag) * 8):
        # get the integer value for the next alphabet letter,
        # wrapping around every 26 chars

        cover = ord(text[i%26])

        # keep this so we can write out just the alphabet

        untouched.append(chr(cover))

        # get the integer value for the secret letter that
        # we're writing

        char = ord(flag[i//8])

        # check if the ith bit is set, going from least to
        # most significant

        bit = 1 if char & (1 << (i%8)) else 0

        # erase the lowest bit of the cover integer, then replace it
        # with the ith bit of the secret

        cover = (cover & ~1) + bit
        result.append(chr(cover))

    output.write("".join(result))
    output_normal.write("".join(untouched))

if sys.argv[1] == "decode":
    text = open(sys.argv[2]).read()
    next_char = 0
    result = []

    for i in range(len(text)):
        shift = (i%8)
        # check if the lowest bit of the character is set

        bit = ord(text[i]) & 1

        # shift it left i%8 times - so between 0 and 7

        next_char |= bit << shift

        # after we check eight characters, we have eight bits,
        # so we can write out a single character
        if i % 8 == 7:
            result.append(chr(next_char))
            next_char = 0
    
    print("".join(result))
