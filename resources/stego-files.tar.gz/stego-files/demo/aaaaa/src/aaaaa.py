import sys

secret = open(sys.argv[1]).read()
output = open(sys.argv[2], "w")

result = []

for char in secret:
    result.append("A"*ord(char))

output.write(" ".join(result))
