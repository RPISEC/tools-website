import sys

# read in the stego'd message
text = open(sys.argv[1]).read()

result = []
# break it up at the spaces, and then, for each piece...
for part in text.split(" "):
    # ...find the length of that piece
    value = len(part)
    # ...and then convert that into a character
    char = chr(value)
    result.append(char)

# the join method makes a string by combining every element of the array,
# with the string on the left placed between each element.
# so, an empty string just glues all the characters together
print("".join(result))
