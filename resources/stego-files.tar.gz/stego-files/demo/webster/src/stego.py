import sys
import random

secret = open(sys.argv[1])
words = open(sys.argv[2]).readlines()
output = open(sys.argv[3], "w")

choices = {}

for word in words:
    c = word[0].lower()
    if c not in choices:
        choices[c] = []
    choices[c].append(word.lower().strip())

result = []

for char in secret.read():
    if char in choices:
        result.append(random.choice(choices[char]))
    else:
        result.append(char)

output.write(" ".join(result))
