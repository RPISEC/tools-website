#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct terrible_struct {
    void (* foo)();
} terrible;

void lose() {
    printf("Everything is ok\n");
}

void win() {
    printf("Oh no!\n");
}

int main(int argc, char** argv) {
    char* whatever = malloc(sizeof(terrible));
    terrible* foo = malloc(sizeof(terrible));

    printf("%p %p \n", whatever, foo);
    
    foo->foo = lose;

    foo->foo();

    printf("I can't wait to go %p!\n", foo->foo);

    fgets(whatever, 1024, stdin);

    printf("Time to go to %p\n", foo->foo);

    foo->foo();
    
}