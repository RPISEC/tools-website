#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
	char *x = malloc(1 << 20);
	strcpy(x, "Hello there!\n");
	printf("Start: %p\n", x);
	char *y = realloc(x, (1 << 21));
	printf("Stale: %p\n", x);
	printf("Fresh: %p\n", y);
	strcpy(y, "HELLO THERE!\n");

	printf("Stale str: %s", x);
	printf("Fresh str: %s", y);
}
