#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char** argv) {
    int allocsize = 32;
    char* a = malloc(allocsize);
    char* b = malloc(allocsize);
    char* c = malloc(allocsize);

    memset(a, 'A', allocsize);
    memset(b, 'B', allocsize);
    memset(c, 'C', allocsize);

    printf("a contains: ");
    fwrite(a, sizeof(char), allocsize, stdout);
    printf("\n");
    printf("b contains: ");
    fwrite(b, sizeof(char), allocsize, stdout);
    printf("\n");
    printf("c contains: ");
    fwrite(c, sizeof(char), allocsize, stdout);
    printf("\n");

    printf("a: %p\nb: %p\nc: %p\n\n", a, b, c);

    free(a);
    free(b);
    
    strcpy(a, "Nothing wrong here!");
    free(a);

    a = malloc(allocsize);
    b = malloc(allocsize);
    c = malloc(allocsize);

    // Replace nulls with @ to make the output more clear

    for (size_t i = 0; i < 32; i++) {
        a[i] = a[i] ? a[i] : '@';
        b[i] = b[i] ? b[i] : '@';
        c[i] = c[i] ? c[i] : '@';
    }

    printf("\na contains: ");
    fwrite(a, sizeof(char), allocsize, stdout);
    printf("\n");
    printf("b contains: ");
    fwrite(b, sizeof(char), allocsize, stdout);
    printf("\n");
    printf("c contains: ");
    fwrite(c, sizeof(char), allocsize, stdout);
    printf("\n");

    printf("\n");

    printf("a: %p\nb: %p\nc: %p\n", a, b, c);
}