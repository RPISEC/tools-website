#include <string.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {
  char *input = argv[1];

  if (strncmp("swordfish", input, strlen(input)) == 0) {
    printf("Correct!\n\n");
  } else {
    printf("No >:C\n\n");
  }
}