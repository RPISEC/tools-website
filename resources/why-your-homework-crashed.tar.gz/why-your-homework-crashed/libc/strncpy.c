#include <string.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
  char a[8];
  char b[8];
  char c[8];
  char d[8];

  strncpy(a, "AAAAAAAA", 8);
  strncpy(b, "BBBB", 8);
  strcpy(c, a);
  
  printf("a: %s\n", a);
  printf("b: %s\n", b);
  printf("c: %s\n", c);
  printf("d: %s\n", d);
}