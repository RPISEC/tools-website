// gcc -zexecstack -fno-stack-protector -no-pie -O0 power-of-gets.c -o power_of_gets.out
#include <stdio.h>
#include <stdlib.h>

int main()
{
    char array[128];
    puts("RPISEC FIREWALL v1.1");
    puts("Changes:\n\t1. Removed backdoor that allowed executing arbitrary user input");
    puts("Try and get and shell from me!");
    printf("Address of array is %p\n", &array);
    puts("Enter your shellcode:");

    // Since we found the back door, there's no way someone can execute arbitrary code.
    // Let's just use the simpler gets then and make the code more readable
    gets(array);
    return EXIT_SUCCESS;
}
