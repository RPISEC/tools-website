// gcc -zexecstack -O0 shellcode-intro.c -o shellcode-intro.out
#include <stdio.h>
#include <stdlib.h>

int main()
{
    puts("RPISEC FIREWALL v1.0");
    puts("Try and get and shell from me!");
    puts("Enter your shellcode:");

    char array[128];
    fgets(array, sizeof(array), stdin);

    // BACKDOOR inserted via ELABORATE SUPPLY CHAIN ATTACK
    // GREETZ to crux
    // Cast array to a function pointer and call it
    void (*shellcode)(void) = &array;
    (*shellcode)();
    return EXIT_SUCCESS;
}
