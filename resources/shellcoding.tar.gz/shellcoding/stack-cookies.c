// gcc -zexecstack -fstack-protector -no-pie -O0 stack-cookies.c -o stack-cookies.out

#include <stdio.h>
#include <stdlib.h>

const int ARRAY_SIZE = 100;

int readInt()
{
    char option[16];
    fgets(option, sizeof(option), stdin);

    return atoi(option);
}

void loadUptime(int* array)
{
    for (int i = 0; i < ARRAY_SIZE; ++i)
    {
        array[i] = rand();
    }
}

int main()
{
    puts("RPISEC FIREWALL v1.2");
    puts("Changes:\n\t1. Replaced insecure gets.\n\t2. Added network management features");

    int array[ARRAY_SIZE];

    printf("The address of the array is %p\n",&array);

    // Retrieve uptime using RPISEC API
    loadUptime(&array);

    while(1)
    {
        puts("Options:\n\t1. Check uptime of a server\n\t2. Set uptime of a server \n\t3. Exit");
        switch (readInt())
        {
            case 1:
            {
                puts("Enter the ID of the server:");
                int server = readInt();
                printf("The uptime of server %d is %d\n", server, array[server]);
                continue;
            }
            case 2:
            {
                puts("Enter the ID of the server:");
                int server = readInt();
                puts("Enter the new uptime:");
                int uptime = readInt();

                if (server > 0x100)
                {
                    puts("Invalid choice!");
                    continue;
                }
                array[server] = uptime;
                puts("Uptime set.");
                continue;
            }
            case 3:
            {
                goto EXIT;
            }
            default:
            {
                continue;
            }
        }

        break;
    }
    EXIT:
    return EXIT_SUCCESS;
}
