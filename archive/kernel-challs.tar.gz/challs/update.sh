#!/bin/sh
cd $1/initramfs
find . -print0 | sudo cpio --null -ov --format=newc | gzip -9 > ../ramfs.gz
