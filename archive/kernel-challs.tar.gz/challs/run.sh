#!/bin/sh
qemu-system-x86_64 -kernel bzImage -initrd $1/ramfs.gz -nographic -append "console=ttyS0 root=/dev/ram rw"
