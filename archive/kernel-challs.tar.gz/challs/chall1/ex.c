#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/mman.h>
#include <string.h>
#include <stdlib.h>

// how to mmap a fixed address:
// char* m = mmap([address here], 0x1000, PROT_READ|PROT_WRITE|PROT_EXEC, MAP_FIXED|MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
// copy shellcode there:
// char sc[] = {0x90, 0xcc};
// memcpy(m, sc, sizefo(sc));
//
// you can cast to long* to write longs
// e.g ((long*)m)[1] = 0x4141414141414141;
// Have fun!

int main()
{
	int fd = open("/proc/sched", O_RDWR);
	char b;
	read(fd, &b, 1); //pop off queue
	write(fd, "7", 2); //add to queue
	return 0;
}
