#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <string.h>

// how to mmap a fixed address:
// char* m = mmap([address here], 0x1000, PROT_READ|PROT_WRITE|PROT_EXEC, MAP_FIXED|MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
// copy shellcode there:
// char sc[] = {0x90, 0xcc};
// memcpy(m, sc, sizefo(sc));
// Have fun!

int main()
{
	int fd = open("/proc/calc", O_WRONLY);
	char* s = "17+34";
	write(fd, s, 6);
	return 0;
}
