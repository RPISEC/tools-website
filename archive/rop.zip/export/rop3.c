
#include <stdio.h>

//gcc -m32 -fno-stack-protector rop3.c -o rop3 -no-pie

//void win() {
//    printf("You did it!\n");
//    system("/bin/sh");
//}

int main() {
    //Disable buffering (ignore this)
    setvbuf(stdout, 0, _IONBF, 0);

    printf("-[      \033[32mWelcome to \033[1;31mRPISEC\033[0;32m reward points!\033[0m      ]-\n");
    printf("-[         \033[33;1mv1.2                               \033[0m]-\n");
    printf("-[      \033[33mSomeone was leaking our secrets >:(   \033[0m]-\n");
    printf("-[  \033[33mLets see how you get them now!            \033[0m]-\n");
    printf("Can you still pwn me?\n");
    void* fd = stdin;

    char name[64];
    char password[64];
    printf("What do they call you: ");
    read(0, name, 64);
    printf("Welcome %s!  Whats your password?\n", name);
    fscanf(stdin, "%s", password);

    printf("Account created!  Goodbye!\n");

    return 0;
}
