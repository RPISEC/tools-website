
#include <stdio.h>
#include <stdlib.h>

//gcc -m32 -fno-stack-protector --static uaf.c -o uaf -no-pie

void win() {
    printf("You did it!\n");
    system("/bin/sh");
}

struct Apple {
    char name[16];
    char color[8];
};

struct Orange {
    void (*print)(char*);
    char name[16];
    // we can assume the color....
};

int main() {
    //Disable buffering (ignore this)
    setvbuf(stdout, 0, _IONBF, 0);

    printf("-[      \033[32mWelcome to \033[1;31mRPISEC\033[0;32m Fruit Stand!!!\033[0m      ]-\n");
    printf("-[         \033[33;1mv1.2                               \033[0m]-\n");
    printf("-[      \033[33mUse this for all of your fruit needs! \033[0m]-\n");
    printf("-[  \033[33mThe most secure fruit stand of all time!  \033[0m]-\n");
    printf("Can you still pwn me? \n");

    struct Apple* apple = NULL;malloc(sizeof(struct Apple));
    struct Orange* orange = NULL;malloc(sizeof(struct Orange));

    while (1) {
        printf("1. Create an apple!\n2. Create an orange!\n3. Delete the apple!\n4. Name the Apple!\n5. Name the Orange!\n6. Print your fruits!\n>>");
        int choice;
        fscanf(stdin, "%d", &choice);
        getchar();
        if (choice == 1) {
            apple = malloc(sizeof(struct Apple));
            printf("allocated apple\n");
        } else if (choice == 2) {
            orange = malloc(sizeof(struct Orange));
            orange->print = puts;
            printf("allocated orange\n");
        } else if (choice == 3) {
            free(apple);
            printf("freed apple\n");
        } else if (choice == 4) {
            fgets(apple->name, 16, stdin);
            printf("set apple name to %s\n", apple->name);
        } else if (choice == 5) {
            fgets(orange->name, 16, stdin);
            printf("set orange name to %s\n", orange->name);
        } else if (choice == 6) {
            printf("%s\n", apple->name);
            orange->print(orange->name);
        }
    }

    char name[64];
    printf("What do they call you: ");
    fscanf(stdin, "%s", name);
    printf("Welcome young hacker...  Enjoying the DEP?!  What u gonna do about it hmmmmmm?\n");

    return 0;
}
