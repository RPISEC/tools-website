import xmlparser

xmlparser.show("thousand.xml")