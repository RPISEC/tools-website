import xmlparser

xmlparser.show("nested.xml")