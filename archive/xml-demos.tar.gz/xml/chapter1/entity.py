import xmlparser

xmlparser.show("entity.xml")