import lxml.etree
import sys

def show(file):
    parser = lxml.etree.XMLParser(huge_tree=True)

    parsed = lxml.etree.parse(file, parser).getroot()

    print("Raw file: \n")
    print(open(file).read())

    print()

    print("Parsed file: \n")
    print(lxml.etree.tostring(parsed, pretty_print=True).decode("utf-8"))