import http.server
import sys
import signal

def signal_handler(sig, frame):
    print("Not launching ze missiles.")
    sys.exit(0)

class LaunchNukesInResponseToGET(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/nuclear_missile_endpoint/v2/launch/verysecretvalue":
            self.send_response(200, 'OK')
            self.end_headers()
            self.wfile.write("Thank you for launching the missiles! Have a great day (:".encode("utf-8"))
            print("Launching ze missiles...")
            sys.exit(0)
        else:
            self.send_response(404, 'not OK :(')
            self.end_headers()
            self.wfile.write("No missiles here!".encode("utf-8"))

signal.signal(signal.SIGINT, signal_handler)

server = http.server.HTTPServer(('', 1337), LaunchNukesInResponseToGET)
server.serve_forever()
