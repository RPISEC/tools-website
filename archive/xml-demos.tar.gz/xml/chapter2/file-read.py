import xmlparser

xmlparser.show("file-read.xml")