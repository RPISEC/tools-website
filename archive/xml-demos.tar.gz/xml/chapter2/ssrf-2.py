import xmlparser

xmlparser.show("ssrf-2.xml")