import xmlparser

xmlparser.show("external-dtd-malformed.xml", True)