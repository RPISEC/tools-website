import xmlparser

xmlparser.show("ssrf.xml")