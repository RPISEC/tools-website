import xmlparser

xmlparser.show("external-dtd.xml", True)