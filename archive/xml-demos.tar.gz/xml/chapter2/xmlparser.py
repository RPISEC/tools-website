import lxml.etree
import sys

def show(file, dtd_validation=False):
    parser = lxml.etree.XMLParser(no_network=False, dtd_validation=dtd_validation)

    parsed = lxml.etree.parse(file, parser).getroot()

    print("Raw file: \n")
    print(open(file).read())

    print()

    print("Parsed file: \n")
    print(lxml.etree.tostring(parsed, pretty_print=True).decode("utf-8"))