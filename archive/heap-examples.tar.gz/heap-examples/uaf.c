#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct terrible_struct {
    void (* foo)();
} terrible;

void lose() {
    printf("Everything is ok\n");
}

void win() {
    printf("Oh no!\n");
}

int main(int argc, char** argv) {
    char* whatever = malloc(sizeof(terrible));

    free(whatever);

    terrible* foo = malloc(sizeof(terrible));

    printf("%p %p \n", whatever, foo);
    
    foo->foo = lose;

    foo->foo();

    *whatever = win;

    foo->foo();
    
}