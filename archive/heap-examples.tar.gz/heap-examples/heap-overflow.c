#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char** argv) {
    char* foo = malloc(10);
    char* bar = malloc(10);

    fgets(foo, 1024, stdin);

    printf("foo p: %p\n", foo);
    printf("bar p: %p\n", bar);

    printf("foo: %s\n", foo);
    printf("bar: %s\n", bar);
    
}