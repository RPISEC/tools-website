#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char** argv) {
    char* a = malloc(10);
    char* b = malloc(10);
    char* c = malloc(10);

    printf("a: %p\nb: %p\nc: %p\n\n", a, b, c);

    free(a);
    free(b);
    free(c);

    a = malloc(10);
    b = malloc(10);
    c = malloc(10);

    printf("a: %p\nb: %p\nc: %p\n", a, b, c);
}