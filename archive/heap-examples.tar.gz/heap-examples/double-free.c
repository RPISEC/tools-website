#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char** argv) {
    char* a = malloc(10);
    char* b = malloc(10);
    char* c = malloc(10);


    int allocsize = 10;
    char* ptrs[7];
    size_t i;
    for (i = 0; i < 7; i++) {
        ptrs[i] = malloc(allocsize);
    }

    // Fill the tcache.
    for (i = 0; i < 7; i++) {
        free(ptrs[i]);
    }
    memcpy(a, "hello!", 16);

    printf("a contains: %s\n\n", a);

    printf("a: %p\nb: %p\nc: %p\n\n", a, b, c);

    free(a);
    free(b);
    free(a);

    // Empty the tcache
    for (i = 0; i < 7; i++) {
        ptrs[i] = malloc(allocsize);
    }

    a = malloc(10);
    b = malloc(10);
    c = malloc(10);

    printf("a: %p\nb: %p\nc: %p\n", a, b, c);
}