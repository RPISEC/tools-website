
#include <stdio.h>

//gcc -m32 -fno-stack-protector rop2.c -o rop2 -no-pie

//void win() {
//    printf("You did it!\n");
//    system("/bin/sh");
//}

char name[64];

int main() {
    //Disable buffering (ignore this)
    setvbuf(stdout, 0, _IONBF, 0);

    printf("-[      \033[32mWelcome to \033[1;31mRPISEC\033[0;32m reward points!\033[0m      ]-\n");
    printf("-[         \033[33;1mv1.2                               \033[0m]-\n");
    printf("-[      \033[33maaaaaaaaaa pls stop hacking us        \033[0m]-\n");
    printf("-[  \033[33mThis ASLR sh ould slow you down...        \033[0m]-\n");
    printf("Can you still pwn me? \033[30mstdin is at %08x...\033[0m\n",stdin); 

    char name[64];
    printf("What do they call you: ");
    fscanf(stdin, "%s", name);
    printf("Welcome young hacker...  Where's your gadgets now?\n");

    return 0;
}
