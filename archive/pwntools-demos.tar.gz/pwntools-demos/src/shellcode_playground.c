#include <stdio.h>
#include <sys/mman.h>
#include <stdlib.h>

int main() {
	setvbuf(stdout, NULL, _IONBF, 0);

	printf("Enter some shell code!\n");

	// Get some RWX memory to read write and execute
	void *code = mmap(NULL, 256, PROT_READ|PROT_WRITE|PROT_EXEC, MAP_ANON|MAP_PRIVATE, 0, 0);
	if (code == MAP_FAILED) {
		printf("Nevermind! mmap failed!\n");
		return 1;
	}
	fread(code, 1, 256, stdin);

	// Fancy way of saying "assume code is a function and call it"
	((void(*)())code)();

	return 0;
}
