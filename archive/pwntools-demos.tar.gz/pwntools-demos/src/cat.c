#include <stdio.h>

int main() {
	setvbuf(stdout, NULL, _IONBF, 0);

	char buffer[256];
	while (1) {
		// There are two vulnerabilities here! One less obvious than the other...
		printf(gets(buffer));
		printf("\n");
	}
}
