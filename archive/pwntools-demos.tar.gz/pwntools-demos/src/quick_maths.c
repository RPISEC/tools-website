#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int main() {
	setvbuf(stdout, NULL, _IONBF, 0);

	srand(time(NULL));

	char buffer[256];
	for (int i = 0; i < 100; i ++) {
		int test0 = rand() & 0x7fff;
		int test1 = rand() & 0x7fff;

		printf("What is %d * %d?\n", test0, test1);
		gets(buffer);
		int response = atoi(buffer);

		if (response != test0 * test1) {
			printf("Nope, that's not it!\n");
			return 1;
		}
	}

	printf("You got it!\n");
	printf("flag{math_is_much_easier_for_computers}\n");
	return 0;
}
