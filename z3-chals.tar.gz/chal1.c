#include <limits.h>
#include <string.h>
#include <stdio.h>

// rotate right by 1
unsigned int ror(unsigned int x) {
  // this should be optimized away to a simple 'ror'
  return (x >> 1) | ((x & 0x1) << (sizeof(int) * CHAR_BIT) - 1);
}

char pass[32] = {};

int check_login(char* buf) {
  unsigned int accumulator = 0;
  // runs a fixed number of times!
  for (int i = 0; i < sizeof (pass); ++i) {
    accumulator = ror(accumulator);
    // we use char, so a sign extension happens!
    // if we used unsigned char, then zero extension would happen!
    accumulator ^= buf[i];
  }
  return accumulator == 0x9a005e40;
}

int main() {
  char text[] =
    "+----------------------------------------+\n"
    "|              Super Secret              |\n"
    "|             Backdoor  v0.1             |\n"
    "+----------------------------------------+\n\n"
    "                 Passcode\n"
    "  >>>________________________________<<<\r  >>>";

  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stdin, NULL, _IONBF, 0);

  printf(text);

  fread(pass, 1, sizeof (pass), stdin);

  puts("");
  if (check_login(pass)) {
    puts("success!");
  } else {
    puts ("incorrect!");
  }
}
