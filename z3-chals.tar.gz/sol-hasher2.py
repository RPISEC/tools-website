import z3
import subprocess

max_length = 10
names = ['x{}'.format(i) for i in range(max_length)]
chars = [z3.Int(n) for n in names]

n2 = 593779930

# notice we run into 'path explosion', as each for loop iteration adds another branch
# this isn't too bad since we are only doing a small, finite number of iterations
def for_loop_iter(n, i):
    # if this is the last iteration (we are at max number of characters),
    # this must be a null byte
    # the n we have accumulated so far must be equal to the result,
    # n == n2 (modular arithmetic since we need to account for overflow)
    if i == len(chars) - 1:
        return z3.And(chars[i] == 0, (n % (2**32)) == n2)
    # recursive case
    return z3.If(chars[i] == 0,
                 # if this is a null byte, we exit the loop, at which point
                 # our 'postcondition' constraint is n == n2
                 (n % (2**32)) == n2,
                 # if this is not a null byte, we apply this iteration to n and recurse
                 # this char must also be within the lowercase ascii alphabet
                 z3.And(for_loop_iter(n * 31 + chars[i], i + 1),
                        chars[i] >= ord('a'),
                        chars[i] <= ord('z')))

def do_hasher(password):
    print('Testing password: {}'.format(password))
    d = subprocess.check_output(["java", "Hasher", password])
    print('Hasher output: {}'.format(d.decode('ascii')))

if __name__ == '__main__':
    s = z3.Solver()
    
    s.add(for_loop_iter(7, 0))

    # will find a correct value, but won't minimize (so we don't really get the correct value)
    if s.check().r != 1:
        print ('not sat!')
    else:
        m = s.model()
        string = ''.join(chr(m.evaluate(c, model_completion=True).as_long()) for c in chars)
        # remove first null byte, and everything after
        clean_string = string[:string.index('\x00')]
        do_hasher(clean_string)

    # z3 has some optimization functionality, but this likely is more trouble than its worth
    # We would probably have to make the array symbolic and use a symbolic length

    # This method we keep trying longer strings until we can get a solution (satisfiable)
    for char in chars:
        s.push()
        s.add(char == 0)
        if s.check().r == 1:
            m = s.model()
            string = ''.join(chr(m.evaluate(c, model_completion=True).as_long()) for c in chars)
            # remove first null byte, and everything after
            clean_string = string[:string.index('\x00')]
            do_hasher(clean_string)
            break
        # revert changes since last push (remove the constraint that char is null byte)
        s.pop()
