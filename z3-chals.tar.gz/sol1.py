import z3

int_size = 32
buf_length = 32

solution = z3.BitVecVal(0x9a005e40, int_size)

if __name__ == '__main__':
    solver = z3.Solver()

    # variables to solve for
    chars = [z3.BitVec('char{}'.format(i), 8) for i in range(buf_length)]

    accumulator = z3.BitVecVal(0, int_size)
    for i in range(buf_length):
        # sign extension uses the number of additional bits to extend by
        # so going from 8 bit (char) to 32 bit (int) would require SignExt(24, myChar)
        accumulator = z3.RotateRight(accumulator, 1) ^ z3.SignExt(int_size - 8, chars[i])

    # accumulator is now an expression composed of xors and rotates
    # add the constraint that this expression must be the 'solution' value
    solver.add(accumulator == solution)

    if solver.check().r != 1:
        print ("not satisfiable!")
    else:
        model = solver.model()
        # model_completion=True might be necessary, if some variables are unconstrained
        result = [model.evaluate(a, model_completion=True).as_long() for a in chars]
        # print the python hex escaped string for this
        escaped_string = ''.join(['\\x{:02x}'.format(i) for i in result])
        print ('escaped string:')
        print (escaped_string)
