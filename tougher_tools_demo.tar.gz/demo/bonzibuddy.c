#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

void bonzi_is_angry() {
    printf("TOO SLOW! You have been cursed with 100 copies of Bonzi Buddy 3\n");
    exit(1);
}
int main(int argc, char** argv) {
    printf("Hi there! I'm Bonzi Buuddy. What do you want me to do?\n");
    printf("I can:\n");
    printf("tell a joke\n");
    printf("segfault\n");
    printf("give the flag\n");
    printf("\n");

    char buf[1024];

    fgets(buf, 255, stdin);

    if (strcmp(buf, "tell a joke\n") == 0) {
        printf("The RIT security club\n\n");
    } else if (strcmp(buf, "segfault\n") == 0) {
        printf("Wheeeeeeeeeee!");
        int* oops = 0;
        *oops = 0;
    } else if (strcmp(buf, "give the flag\n") == 0) {
        char challenge[17];

        signal(SIGALRM, bonzi_is_angry);

        for (int i=0; i<16; i++) {
            challenge[i] = 0x41 + (rand() % 26);
        }

        challenge[16] = 0;

        printf("Quick, type this: %s\n", challenge);

        alarm(1);

        char response[17];

        fgets(response, 17, stdin);

        if (strncmp(response, challenge, 16) == 0) {
            printf("You win! The flag is RPISEC_WAS_HERE");
        } else {
            printf("no");
        }
    }
    return 0;
}
