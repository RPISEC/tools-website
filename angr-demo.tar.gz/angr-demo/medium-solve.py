import angr

proj = angr.Project("./medium")
simgr = proj.factory.simgr()
simgr.explore(find = lambda output: b"Correct" in output.posix.dumps(1))
print(simgr.found[0].posix.dumps(0))