#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char** argv) {
    int input;
    printf("Can you give me the password? ===> ");

    scanf("%d", &input);

    if (((input * 2 - 1265) / 10) == 1337) {
        printf("Correct!\n\n");
    } else {
        printf("No :(\n\n");
    }
}