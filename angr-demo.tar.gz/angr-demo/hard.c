#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void wtf(int* val) {
    *val = *val + 1;
}

int main(int argc, char** argv) {
    int input;
    printf("Can you give me the password? ===> ");

    scanf("%d", &input);

    int value = 0;
    for (int j=0; j<input; j++) {
        wtf(&value);
    }

    if (value == 10) {
        printf("Correct!\n\n");
    } else {
        printf("No :(\n\n");
    }
}